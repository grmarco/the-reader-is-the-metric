- For ACM CHI paper Art or Artifice? Large Language Models and the False Promise of Creativity 
  - Go to Folder Art_or_Artifice

- For new paper Can AI writing be salvaged? Mitigating Idiosyncrasies and Improving Human-AI Alignment in the Writing Process through Edits
  - Go to Writing_Alignment
